@echo off
chcp 65001 >nul
cd /d "%~dp0"
set ERR=0
if exist "XiangqiStudio.exe" (echo [通过] XiangqiStudio.exe) else (echo [失败] 缺少 XiangqiStudio.exe&set ERR=1)
if exist "config.json" (echo [通过] config.json) else (echo [失败] 缺少 config.json&set ERR=1)
if exist "README_使用说明.txt" (echo [通过] 使用说明) else (echo [失败] 缺少使用说明&set ERR=1)
if exist "engine\fairy-stockfish-largeboard_x86-64-bmi2.exe" (echo [通过] BMI2引擎) else (echo [提醒] 尚未放入BMI2引擎)
if exist "engine\xiangqi-zy.nnue" (echo [通过] xiangqi-zy.nnue) else (echo [提醒] 尚未放入NNUE文件)
echo.
if "%ERR%"=="0" (echo 发布包主体完整) else (echo 发布包不完整，请重新编译)
pause
exit /b %ERR%
