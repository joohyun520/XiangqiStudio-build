from __future__ import annotations
import csv, json, os, queue, shutil, sqlite3, subprocess, threading, time, urllib.parse, urllib.request

class CloudBook:
    def __init__(self, timeout=1.2,endpoints=None):
        self.timeout=max(.2,float(timeout));self.endpoints=endpoints or ['https://www.chessdb.cn/chessdb.php','http://www.chessdb.cn/chessdb.php'];self.failures={};self.cooldown={}
    def query(self,fen):
        for endpoint in self.endpoints:
            if self.cooldown.get(endpoint,0)>time.time():continue
            url=endpoint+'?'+urllib.parse.urlencode({'action':'queryall','board':fen,'showall':'1'})
            try:
                with urllib.request.urlopen(url,timeout=self.timeout) as r:text=r.read().decode('utf-8','ignore')
                result=[]
                for item in text.replace('\n','|').split('|'):
                    fields=dict(x.split(':',1) for x in item.split(',') if ':' in x);move=fields.get('move','')
                    if len(move)>=4:result.append((move,fields.get('score',''),fields.get('winrate','')))
                self.failures[endpoint]=0
                if result:return result
            except Exception:
                self.failures[endpoint]=self.failures.get(endpoint,0)+1
                if self.failures[endpoint]>=3:self.cooldown[endpoint]=time.time()+60
        return []

class CloudCache:
    def __init__(self,path,ttl_days=7):
        os.makedirs(os.path.dirname(path) or '.',exist_ok=True);self.ttl=max(1,int(ttl_days))*86400;self.lock=threading.RLock();self.conn=sqlite3.connect(path,check_same_thread=False,timeout=5)
        self.conn.execute('PRAGMA journal_mode=WAL');self.conn.execute('CREATE TABLE IF NOT EXISTS cache(fen TEXT PRIMARY KEY,payload TEXT NOT NULL,updated INTEGER NOT NULL)');self.conn.commit()
    def get(self,fen,allow_stale=False):
        with self.lock:row=self.conn.execute('SELECT payload,updated FROM cache WHERE fen=?',(fen,)).fetchone()
        if not row or (not allow_stale and int(time.time())-row[1]>self.ttl):return []
        try:return [tuple(x) for x in json.loads(row[0])]
        except Exception:return []
    def put(self,fen,items):
        if not items:return
        with self.lock:self.conn.execute('INSERT INTO cache(fen,payload,updated) VALUES(?,?,?) ON CONFLICT(fen) DO UPDATE SET payload=excluded.payload,updated=excluded.updated',(fen,json.dumps(items,ensure_ascii=False),int(time.time())));self.conn.commit()
    def count(self):
        with self.lock:return int(self.conn.execute('SELECT COUNT(*) FROM cache').fetchone()[0])
    def clear(self):
        with self.lock:self.conn.execute('DELETE FROM cache');self.conn.commit()
    def close(self):
        with self.lock:self.conn.close()

class JsonBook:
    def __init__(self,path): self.path=path; self.data={}; self.load()
    def load(self):
        try:
            with open(self.path,'r',encoding='utf-8') as f:self.data=json.load(f)
        except Exception:self.data={}
    def moves(self,fen): return self.data.get(fen,[])
    def add(self,fen,move):
        values=self.data.setdefault(fen,[])
        if move not in values: values.append(move)
        os.makedirs(os.path.dirname(self.path) or '.',exist_ok=True)
        with open(self.path,'w',encoding='utf-8') as f:json.dump(self.data,f,ensure_ascii=False)
    def remove(self,fen,move):
        values=self.data.get(fen,[])
        if move in values:values.remove(move)
        if not values:self.data.pop(fen,None)
        os.makedirs(os.path.dirname(self.path) or '.',exist_ok=True)
        with open(self.path,'w',encoding='utf-8') as f:json.dump(self.data,f,ensure_ascii=False)
    def count(self):return sum(len(v) for v in self.data.values())
    def backup(self,destination):
        os.makedirs(os.path.dirname(destination) or '.',exist_ok=True)
        if os.path.isfile(self.path):shutil.copy2(self.path,destination)
        else:
            with open(destination,'w',encoding='utf-8') as f:json.dump(self.data,f,ensure_ascii=False)
    def restore(self,source):
        with open(source,'r',encoding='utf-8') as f:data=json.load(f)
        if not isinstance(data,dict):raise ValueError('不是有效的XiangqiStudio本地库')
        for fen,moves in data.items():
            if not isinstance(fen,str) or not isinstance(moves,list):raise ValueError('本地库结构错误')
        self.data=data;os.makedirs(os.path.dirname(self.path) or '.',exist_ok=True)
        with open(self.path,'w',encoding='utf-8') as f:json.dump(self.data,f,ensure_ascii=False)

class SQLiteBook:
    def __init__(self,path,legacy_json=''):
        self.path=path;os.makedirs(os.path.dirname(path) or '.',exist_ok=True);self.lock=threading.RLock();self.conn=sqlite3.connect(path,check_same_thread=False,timeout=5)
        self.conn.execute('PRAGMA journal_mode=WAL');self.conn.execute('PRAGMA synchronous=NORMAL');self.conn.execute('PRAGMA busy_timeout=5000')
        self.conn.execute('CREATE TABLE IF NOT EXISTS moves(fen TEXT NOT NULL, move TEXT NOT NULL, source TEXT NOT NULL DEFAULT "local", score INTEGER, updated INTEGER NOT NULL, PRIMARY KEY(fen,move))')
        self.conn.execute('CREATE INDEX IF NOT EXISTS idx_moves_fen ON moves(fen)');self.conn.commit()
        if legacy_json and os.path.isfile(legacy_json) and self.count()==0:self.migrate_json(legacy_json)
    def moves(self,fen):
        with self.lock:return [r[0] for r in self.conn.execute('SELECT move FROM moves WHERE fen=? ORDER BY COALESCE(score,-999999) DESC,updated DESC',(fen,))]
    def entries(self,fen):
        with self.lock:return list(self.conn.execute('SELECT move,score,source FROM moves WHERE fen=? ORDER BY COALESCE(score,-999999) DESC,updated DESC',(fen,)))
    def add(self,fen,move,source='local',score=None):
        if not fen or not move:return
        with self.lock:self.conn.execute('INSERT INTO moves(fen,move,source,score,updated) VALUES(?,?,?,?,?) ON CONFLICT(fen,move) DO UPDATE SET source=excluded.source,score=COALESCE(excluded.score,moves.score),updated=excluded.updated',(fen,move,source,score,int(time.time())));self.conn.commit()
    def remove(self,fen,move):
        with self.lock:self.conn.execute('DELETE FROM moves WHERE fen=? AND move=?',(fen,move));self.conn.commit()
    def count(self):
        with self.lock:return int(self.conn.execute('SELECT COUNT(*) FROM moves').fetchone()[0])
    def position_count(self):
        with self.lock:return int(self.conn.execute('SELECT COUNT(DISTINCT fen) FROM moves').fetchone()[0])
    def source_counts(self):
        with self.lock:return list(self.conn.execute('SELECT source,COUNT(*) FROM moves GROUP BY source ORDER BY COUNT(*) DESC'))
    def set_score(self,fen,move,score):
        with self.lock:self.conn.execute('UPDATE moves SET score=?,updated=? WHERE fen=? AND move=?',(score,int(time.time()),fen,move));self.conn.commit()
    def integrity_check(self):
        with self.lock:return str(self.conn.execute('PRAGMA integrity_check').fetchone()[0])
    def below_score_count(self,threshold):
        with self.lock:return int(self.conn.execute('SELECT COUNT(*) FROM moves WHERE score IS NOT NULL AND score<?',(threshold,)).fetchone()[0])
    def delete_below_score(self,threshold):
        with self.lock:
            before=self.conn.total_changes;self.conn.execute('DELETE FROM moves WHERE score IS NOT NULL AND score<?',(threshold,));self.conn.commit();return self.conn.total_changes-before
    def vacuum(self):
        with self.lock:self.conn.execute('VACUUM');self.conn.execute('PRAGMA optimize');self.conn.commit()
    def migrate_json(self,path):
        try:
            with open(path,'r',encoding='utf-8') as f:data=json.load(f)
            rows=[(fen,m,'json-migration',None,int(time.time())) for fen,values in data.items() for m in values]
            with self.lock:self.conn.executemany('INSERT OR IGNORE INTO moves(fen,move,source,score,updated) VALUES(?,?,?,?,?)',rows);self.conn.commit()
        except Exception:pass
    def backup(self,destination):
        with self.lock:
            out=sqlite3.connect(destination);self.conn.backup(out);out.close()
    def restore(self,source):
        incoming=sqlite3.connect(f'file:{source}?mode=ro',uri=True)
        cols={r[1] for r in incoming.execute('PRAGMA table_info(moves)')}
        if not {'fen','move','source','score','updated'}<=cols:incoming.close();raise ValueError('不是有效的XiangqiStudio SQLite棋库')
        with self.lock:incoming.backup(self.conn);self.conn.commit()
        incoming.close()
    def close(self):
        with self.lock:self.conn.close()
    def import_csv(self,path,progress=None,batch_size=5000):
        processed=skipped=0;batch=[]
        with open(path,'r',encoding='utf-8-sig',newline='') as f:
            reader=csv.DictReader(f)
            if not reader.fieldnames or not {'fen','move'}<=set(reader.fieldnames):raise ValueError('CSV必须包含fen和move列')
            for row in reader:
                fen=(row.get('fen') or '').strip();move=(row.get('move') or '').strip().lower();source=(row.get('source') or 'csv').strip();raw=(row.get('score') or '').strip()
                try:score=int(raw) if raw else None
                except Exception:score=None
                if not fen or len(move)!=4 or move[0] not in 'abcdefghi' or move[2] not in 'abcdefghi' or move[1] not in '0123456789' or move[3] not in '0123456789':skipped+=1;continue
                batch.append((fen,move,source,score,int(time.time())));processed+=1
                if len(batch)>=batch_size:self._insert_batch(batch);batch=[];progress and progress(processed,skipped)
            if batch:self._insert_batch(batch)
        progress and progress(processed,skipped);return processed,skipped
    def _insert_batch(self,rows):
        with self.lock:self.conn.executemany('INSERT INTO moves(fen,move,source,score,updated) VALUES(?,?,?,?,?) ON CONFLICT(fen,move) DO UPDATE SET source=excluded.source,score=COALESCE(excluded.score,moves.score),updated=excluded.updated',rows);self.conn.commit()
    def export_csv(self,path,progress=None,batch_size=5000):
        done=0
        with open(path,'w',encoding='utf-8-sig',newline='') as f:
            writer=csv.writer(f);writer.writerow(['fen','move','source','score','updated'])
            with self.lock:cur=self.conn.execute('SELECT fen,move,source,score,updated FROM moves ORDER BY fen,move')
            while True:
                with self.lock:rows=cur.fetchmany(batch_size)
                if not rows:break
                writer.writerows(rows);done+=len(rows);progress and progress(done)
        return done

class UciEngine:
    def __init__(self): self.p=None; self.lock=threading.Lock(); self.lines=queue.Queue(); self.reader=None; self.protocol=''; self.path=''
    def _spawn(self,path):
        self.p=subprocess.Popen([path],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,encoding='utf-8',errors='ignore',bufsize=1,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        self.lines=queue.Queue();self.reader=threading.Thread(target=self._read,daemon=True);self.reader.start()
    def start(self,path,nnue='',threads=6,hash_mb=1024,multipv=3):
        if not path or not os.path.isfile(path): raise FileNotFoundError('没有找到引擎文件，请先点“选择引擎”')
        self.stop();self.path=path;self._spawn(path);self.send('uci')
        try:self.wait('uciok',3);self.protocol='uci'
        except TimeoutError:
            self.stop();self._spawn(path);self.send('ucci');self.wait('ucciok',6);self.protocol='ucci'
        self.send(f'setoption name Threads value {threads}'); self.send(f'setoption name Hash value {hash_mb}')
        self.send(f'setoption name MultiPV value {multipv}')
        if nnue:self.send(f'setoption name EvalFile value {nnue}')
        self.send('isready'); self.wait('readyok',8)
    def send(self,s):
        if self.p and self.p.stdin:self.p.stdin.write(s+'\n');self.p.stdin.flush()
    def _read(self):
        try:
            for line in self.p.stdout:self.lines.put(line.rstrip())
        except Exception:pass
    def wait(self,token,seconds):
        import time
        end=time.time()+seconds
        while time.time()<end:
            try:line=self.lines.get(timeout=min(.15,max(.01,end-time.time())))
            except queue.Empty:continue
            if token in line:return line
        raise TimeoutError(token)
    def bestmove(self,fen,movetime=1000,on_info=None,wtime=None,btime=None,winc=0,binc=0):
        with self.lock:
            self.send('stop');self.send('position fen '+fen)
            if self.protocol=='uci' and wtime is not None and btime is not None:self.send(f'go wtime {max(1,int(wtime))} btime {max(1,int(btime))} winc {max(0,int(winc))} binc {max(0,int(binc))}')
            else:self.send(f'go movetime {movetime}')
            import time
            end=time.time()+max(5,movetime/1000+4)
            while time.time()<end:
                try:line=self.lines.get(timeout=.15)
                except queue.Empty:continue
                if line.startswith('info ') and on_info:on_info(line)
                if line.startswith('bestmove '):
                    parts=line.split();return parts[1] if len(parts)>1 else ''
            self.send('stop');raise TimeoutError('引擎思考超时，已自动停算')
    def stop(self):
        if self.p:
            try:self.send('quit');self.p.kill()
            except Exception:pass
        self.p=None
    def alive(self):return self.p is not None and self.p.poll() is None
