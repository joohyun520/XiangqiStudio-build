from __future__ import annotations
import csv, json, logging, math, os, random, re, sys, threading, tkinter as tk, time, traceback
from logging.handlers import RotatingFileHandler
from tkinter import filedialog, messagebox, ttk, simpledialog
from xiangqi_core import Board, Move, NAMES
from services import CloudBook, CloudCache, SQLiteBook, UciEngine

APP_DIR=os.path.dirname(sys.executable) if getattr(sys,'frozen',False) else os.path.dirname(os.path.abspath(__file__))
DATA_DIR=os.path.join(os.environ.get('LOCALAPPDATA',APP_DIR),'XiangqiStudio') if os.name=='nt' else os.path.join(APP_DIR,'data')
os.makedirs(DATA_DIR,exist_ok=True);CONFIG=os.path.join(DATA_DIR,'config.json')
LOGGER=logging.getLogger('XiangqiStudio');LOGGER.setLevel(logging.INFO)
ENGINE_PRESETS={
    '快速':{'threads':2,'hash':256,'multipv':1,'movetime':500},
    '均衡':{'threads':4,'hash':1024,'multipv':3,'movetime':1000},
    '强力':{'threads':8,'hash':2048,'multipv':3,'movetime':3000},
}
if not LOGGER.handlers:
    handler=RotatingFileHandler(os.path.join(DATA_DIR,'XiangqiStudio.log'),maxBytes=2*1024*1024,backupCount=3,encoding='utf-8');handler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'));LOGGER.addHandler(handler)

class App(tk.Tk):
    def __init__(self):
        super().__init__(); self.title('XiangqiStudio V7.4'); self.geometry('1240x820'); self.minsize(760,600)
        self.board=Board(); self.replay_moves=[]; self.replay_cursor=0; self.comments={}; self.eval_history={}; self.current_eval={}; self.sel=None; self.busy=False; self.flipped=False; self.setup=False; self.game_start=time.time(); self.query_id=0; self.search_id=0; self.pv_lines={}; self.recommend_move=''; self.eval_cp=0; self.last_info_ui=0; self.clock_running=False; self.red_ms=0; self.black_ms=0; self.last_clock=time.monotonic(); self.result_saved=False; self.current_result=''; self.engine=UciEngine(); self.engine2=UciEngine(); self.thinking_engine=None; self.cloud=CloudBook(); self.cfg=self.load_cfg(); self.book=SQLiteBook(os.path.join(DATA_DIR,'book','local_book.db'),os.path.join(DATA_DIR,'book','local_book.json'));self.cloud_cache=CloudCache(os.path.join(DATA_DIR,'cloud_cache.db'),int(self.cfg.get('cache_days',7)))
        self.base_fen=self.board.fen()
        self.cloud=CloudBook(float(self.cfg.get('cloud_timeout_ms',1200))/1000,self.cfg.get('cloud_endpoints'))
        self.red_left=self.black_left=max(0,int(self.cfg.get('game_minutes',0))*60000);self.timeout_declared=False
        try:self.ui_scale=float(self.cfg.get('ui_scale',1.0))
        except Exception:self.ui_scale=1.0
        self.apply_scale(self.ui_scale)
        try:self.geometry(self.cfg.get('geometry','1240x820'))
        except Exception:self.geometry('1240x820')
        self.build();self.bind_shortcuts();self.draw();self.tick_clock();self.protocol('WM_DELETE_WINDOW',self.close)
    def load_cfg(self):
        for path in (CONFIG,os.path.join(APP_DIR,'config.json')):
            try:
                with open(path,'r',encoding='utf-8') as f:return json.load(f)
            except Exception:pass
        return {'engine':'engine\\fairy-stockfish-largeboard_x86-64-bmi2.exe','engine2':'engine\\fairy-stockfish-largeboard_x86-64-bmi2.exe','nnue':'engine\\xiangqi-zy.nnue','movetime':1000,'cloud':True,'auto':False,'threads':6,'hash':1024,'multipv':3}
    def save_cfg(self):
        with open(CONFIG,'w',encoding='utf-8') as f:json.dump(self.cfg,f,ensure_ascii=False,indent=2)
    def resolve_path(self,path):return path if os.path.isabs(path) else os.path.normpath(os.path.join(APP_DIR,path))
    def apply_scale(self,value):
        self.ui_scale=min(1.8,max(.75,float(value)));self.tk.call('tk','scaling',self.ui_scale)
    def change_scale(self,delta):
        self.apply_scale(self.ui_scale+delta);self.cfg['ui_scale']=round(self.ui_scale,2);self.save_cfg();self.status.set(f'界面缩放 {self.ui_scale:.0%}');self.draw()
    def reset_scale(self):self.apply_scale(1.0);self.cfg['ui_scale']=1.0;self.save_cfg();self.draw()
    def build(self):
        self.build_menu()
        tools=ttk.Frame(self);tools.pack(fill='x',pad=6,pady=(5,1))
        for text,cmd in [('新局',self.new),('悔棋',self.undo),('|<',lambda:self.jump_to(0)),('<',lambda:self.jump_to(self.replay_cursor-1)),('>',lambda:self.jump_to(self.replay_cursor+1)),('>|',lambda:self.jump_to(len(self.replay_moves))),('保存棋谱',self.save_game),('读取棋谱',self.load_game),('恢复现场',self.restore_session),('查询云库',self.query_cloud)]:ttk.Button(tools,text=text,command=cmd).pack(side='left',pad=2)
        engines=ttk.Frame(self);engines.pack(fill='x',pad=6,pady=(1,5))
        for text,cmd in [('启动双引擎',self.start_engine),('立即走棋',self.force_or_go),('走推荐棋',self.play_recommend),('停止',self.stop_search),('引擎设置',self.engine_settings),('系统自检',self.self_test)]:ttk.Button(engines,text=text,command=cmd).pack(side='left',pad=2)
        self.auto=tk.BooleanVar(value=self.cfg.get('auto',False));ttk.Checkbutton(engines,text='红黑连续',variable=self.auto,command=self.toggle_auto).pack(side='left',pad=(8,2))
        self.hints=tk.BooleanVar(value=self.cfg.get('hints',True));ttk.Checkbutton(engines,text='合法箭头',variable=self.hints,command=self.save_visual).pack(side='left')
        self.arrows=tk.BooleanVar(value=self.cfg.get('arrows',True));ttk.Checkbutton(engines,text='箭头',variable=self.arrows,command=self.save_visual).pack(side='left')
        self.recommend_arrow=tk.BooleanVar(value=self.cfg.get('recommend_arrow',True));ttk.Checkbutton(engines,text='推荐箭头',variable=self.recommend_arrow,command=self.save_visual).pack(side='left')
        self.sound=tk.BooleanVar(value=self.cfg.get('sound',True));ttk.Checkbutton(engines,text='声音',variable=self.sound,command=self.save_visual).pack(side='left')
        self.learn=tk.BooleanVar(value=self.cfg.get('learn',False));ttk.Checkbutton(engines,text='自动学习',variable=self.learn,command=self.save_visual).pack(side='left')
        ttk.Label(engines,text='每步ms').pack(side='left',pad=(8,0));self.movetime=tk.IntVar(value=int(self.cfg.get('movetime',1000)));ttk.Spinbox(engines,from_=100,to=600000,increment=100,textvariable=self.movetime,width=7,command=self.save_time).pack(side='left')
        setupbar=ttk.Frame(self);setupbar.pack(fill='x',pad=6,pady=(0,3))
        self.setup_var=tk.BooleanVar(value=False);ttk.Checkbutton(setupbar,text='摆棋模式',variable=self.setup_var,command=self.toggle_setup).pack(side='left')
        self.setup_piece=tk.StringVar(value='红车');self.piece_box=ttk.Combobox(setupbar,textvariable=self.setup_piece,state='readonly',width=7,values=('红帅','红仕','红相','红马','红车','红炮','红兵','黑将','黑士','黑象','黑马','黑车','黑炮','黑卒'));self.piece_box.pack(side='left',pad=4)
        self.side_var=tk.StringVar(value='红方走');ttk.Combobox(setupbar,textvariable=self.side_var,state='readonly',width=7,values=('红方走','黑方走')).pack(side='left')
        ttk.Button(setupbar,text='检查局面',command=self.check_position).pack(side='left',pad=4);ttk.Label(setupbar,text='摆棋时左键放置，右键删除').pack(side='left')
        self.clock_text=tk.StringVar(value='红 00:00.0　黑 00:00.0');ttk.Label(setupbar,textvariable=self.clock_text,font=('Consolas',11)).pack(side='right',pad=8)
        pane=ttk.Panedwindow(self,orient='horizontal');pane.pack(fill='both',expand=True,padx=6,pady=4)
        left=ttk.Frame(pane);right=ttk.Frame(pane,width=330);pane.add(left,weight=3);pane.add(right,weight=2)
        self.cv=tk.Canvas(left,bg='#ead6a6',highlightthickness=0);self.cv.pack(fill='both',expand=True);self.cv.bind('<Configure>',lambda e:self.draw());self.cv.bind('<Button-1>',self.click);self.cv.bind('<Button-3>',self.remove_piece)
        self.status=tk.StringVar(value='就绪：红方走棋');ttk.Label(right,textvariable=self.status,wraplength=310).pack(fill='x',pady=4)
        cols=('move','cn','score','win');self.tree=ttk.Treeview(right,columns=cols,show='headings',height=18)
        for c,t,w in [('move','UCI',70),('cn','中文着法',90),('score','分数',65),('win','来源/胜率',85)]:self.tree.heading(c,text=t);self.tree.column(c,width=w,anchor='center')
        self.tree.pack(fill='both',expand=True);self.tree.bind('<Double-1>',self.play_cloud);self.tree.bind('<Button-3>',self.book_menu)
        self.popup=tk.Menu(self,tearoff=False);self.popup.add_command(label='保存选中着法到本地库',command=self.save_selected_book);self.popup.add_command(label='修改本地着法分数',command=self.edit_book_score);self.popup.add_command(label='从本地库删除选中着法',command=self.remove_selected_book)
        ttk.Label(right,text='对局着法').pack(anchor='w',pady=(5,0))
        self.moves=tk.Listbox(right,height=6,font=('Consolas',10));self.moves.pack(fill='x');self.moves.bind('<Button-3>',self.move_comment_menu)
        self.comment_popup=tk.Menu(self,tearoff=False);self.comment_popup.add_command(label='添加/修改批注',command=self.edit_move_comment);self.comment_popup.add_command(label='删除批注',command=self.delete_move_comment)
        ttk.Label(right,text='引擎主变 / 深度 / 分数 / 速度').pack(anchor='w',pady=(5,0))
        self.analysis=tk.Text(right,height=7,state='disabled',font=('Consolas',10));self.analysis.pack(fill='x');self.analysis.bind('<Double-1>',lambda e:self.play_recommend())
        self.log=tk.Text(right,height=7,state='disabled');self.log.pack(fill='x')
    def build_menu(self):
        menu=tk.Menu(self);self.config(menu=menu)
        filem=tk.Menu(menu,tearoff=False);menu.add_cascade(label='文件',menu=filem);filem.add_command(label='新局  Ctrl+N',command=self.new);filem.add_command(label='读取棋谱  Ctrl+O',command=self.load_game);filem.add_command(label='保存棋谱  Ctrl+S',command=self.save_game);filem.add_separator();filem.add_command(label='导入XQPGN文本',command=self.import_xqpgn);filem.add_command(label='导出XQPGN文本',command=self.export_xqpgn);filem.add_command(label='恢复现场',command=self.restore_session);filem.add_separator();filem.add_command(label='退出',command=self.close)
        gamem=tk.Menu(menu,tearoff=False);menu.add_cascade(label='棋局',menu=gamem);gamem.add_command(label='悔棋  Ctrl+Z',command=self.undo);gamem.add_command(label='暂停/继续计时  Space',command=self.pause_match);gamem.add_separator();gamem.add_command(label='红方认输',command=lambda:self.resign(True));gamem.add_command(label='黑方认输',command=lambda:self.resign(False));gamem.add_command(label='协议和棋',command=self.agree_draw);gamem.add_separator();gamem.add_command(label='翻转棋盘',command=self.flip);gamem.add_command(label='粘贴FEN',command=self.paste_fen);gamem.add_command(label='复制FEN',command=self.copy_fen);gamem.add_command(label='最简局面',command=self.clear_position);gamem.add_command(label='比赛统计',command=self.show_stats)
        engm=tk.Menu(menu,tearoff=False);menu.add_cascade(label='引擎',menu=engm);engm.add_command(label='选择红方引擎',command=self.pick_engine);engm.add_command(label='选择黑方引擎',command=self.pick_engine2);engm.add_command(label='选择NNUE',command=self.pick_nnue);engm.add_command(label='引擎设置',command=self.engine_settings);presetm=tk.Menu(engm,tearoff=False);engm.add_cascade(label='性能配置档',menu=presetm);presetm.add_command(label='快速（低占用）',command=lambda:self.apply_engine_preset('快速'));presetm.add_command(label='均衡（i7推荐）',command=lambda:self.apply_engine_preset('均衡'));presetm.add_command(label='强力（高占用）',command=lambda:self.apply_engine_preset('强力'));engm.add_separator();engm.add_command(label='启动双引擎',command=self.start_engine);engm.add_command(label='立即走棋  F5',command=self.force_or_go);engm.add_command(label='停止  Esc',command=self.stop_search)
        bookm=tk.Menu(menu,tearoff=False);menu.add_cascade(label='棋库',menu=bookm);bookm.add_command(label='查询云库',command=self.query_cloud);bookm.add_command(label='棋库统计',command=self.show_book_stats);bookm.add_command(label='棋库维护',command=self.maintain_book);bookm.add_command(label='清理云库缓存',command=self.clear_cloud_cache);bookm.add_separator();bookm.add_command(label='导入CSV大库',command=self.import_book_csv);bookm.add_command(label='导出CSV大库',command=self.export_book_csv);bookm.add_separator();bookm.add_command(label='备份本地棋库',command=self.backup_book);bookm.add_command(label='恢复本地棋库',command=self.restore_book)
        viewm=tk.Menu(menu,tearoff=False);menu.add_cascade(label='视图',menu=viewm);viewm.add_command(label='放大界面  Ctrl++',command=lambda:self.change_scale(.1));viewm.add_command(label='缩小界面  Ctrl+-',command=lambda:self.change_scale(-.1));viewm.add_command(label='恢复默认缩放',command=self.reset_scale);viewm.add_command(label='翻转棋盘',command=self.flip)
        helpm=tk.Menu(menu,tearoff=False);menu.add_cascade(label='帮助',menu=helpm);helpm.add_command(label='系统自检',command=self.self_test);helpm.add_command(label='查看故障日志',command=self.show_log);helpm.add_command(label='关于',command=lambda:messagebox.showinfo('关于','XiangqiStudio V7.4\nWindows 中国象棋分析与双引擎平台'))
    def bind_shortcuts(self):
        self.bind_all('<Control-n>',lambda e:self.new());self.bind_all('<Control-o>',lambda e:self.load_game());self.bind_all('<Control-s>',lambda e:self.save_game());self.bind_all('<Control-z>',lambda e:self.undo());self.bind_all('<Control-plus>',lambda e:self.change_scale(.1));self.bind_all('<Control-minus>',lambda e:self.change_scale(-.1));self.bind_all('<F5>',lambda e:self.force_or_go());self.bind_all('<Escape>',lambda e:self.stop_search());self.bind_all('<space>',lambda e:self.pause_match())
    def metric(self):
        w,h=max(450,self.cv.winfo_width()),max(520,self.cv.winfo_height());s=min((w-50)/8,(h-50)/9);return 25,s
    def draw(self):
        self.cv.delete('all');o,s=self.metric()
        red_ratio=1/(1+math.exp(-max(-2000,min(2000,self.eval_cp))/300));top=o;bottom=o+9*s;split=bottom-9*s*red_ratio
        self.cv.create_rectangle(5,top,17,bottom,fill='#1b1b1b',outline='#666');self.cv.create_rectangle(5,split,17,bottom,fill='#c62828',outline='');self.cv.create_text(11,max(top+10,min(bottom-10,split)),text=f'{red_ratio*100:.0f}',font=('Arial',8,'bold'),fill='#ffffff')
        for i in range(10):self.cv.create_line(o,o+i*s,o+8*s,o+i*s,width=2)
        for i in range(9):
            self.cv.create_line(o+i*s,o,o+i*s,o+4*s,width=2);self.cv.create_line(o+i*s,o+5*s,o+i*s,o+9*s,width=2)
        self.cv.create_line(o,o+4*s,o,o+5*s,width=2);self.cv.create_line(o+8*s,o+4*s,o+8*s,o+5*s,width=2)
        for y in (0,7):self.cv.create_line(o+3*s,o+y*s,o+5*s,o+(y+2)*s);self.cv.create_line(o+5*s,o+y*s,o+3*s,o+(y+2)*s)
        self.cv.create_text(o+2*s,o+4.5*s,text='楚 河',font=('Microsoft YaHei',int(s*.35),'bold'));self.cv.create_text(o+6*s,o+4.5*s,text='汉 界',font=('Microsoft YaHei',int(s*.35),'bold'))
        for i in range(9):self.cv.create_text(o+i*s,o+9*s+16,text=str(i+1),font=('Arial',9),fill='#55452e')
        for y,row in enumerate(self.board.squares):
            for x,p in enumerate(row):
                if p!='.':
                    vx,vy=(8-x,9-y) if self.flipped else (x,y);X,Y=o+vx*s,o+vy*s; fill='#fff2cf' if p.isupper() else '#e7c987'; color='#c52320' if p.isupper() else '#171717'
                    self.cv.create_oval(X-s*.34,Y-s*.34,X+s*.34,Y+s*.34,fill=fill,width=3,outline=color)
                    self.cv.create_text(X,Y,text=NAMES[p],font=('Microsoft YaHei',int(s*.38),'bold'),fill=color)
        if self.sel:
            x,y=self.sel; x,y=((8-x,9-y) if self.flipped else (x,y));self.cv.create_rectangle(o+(x-.4)*s,o+(y-.4)*s,o+(x+.4)*s,o+(y+.4)*s,outline='#1677ff',width=4)
            if self.hints.get():
                sx,sy=self.sel
                for ty in range(10):
                    for tx in range(9):
                        if self.board.legal(Move(sx,sy,tx,ty)):
                            vx,vy=((8-tx,9-ty) if self.flipped else (tx,ty));self.cv.create_line(o+x*s,o+y*s,o+vx*s,o+vy*s,fill='#1687d9',width=max(2,int(s*.045)),arrow='last',arrowshape=(10,13,5))
        if self.arrows.get() and self.board.history:
            m,_=self.board.history[-1];fx,fy,tx,ty=m.fx,m.fy,m.tx,m.ty
            if self.flipped:fx,fy,tx,ty=8-fx,9-fy,8-tx,9-ty
            self.cv.create_line(o+fx*s,o+fy*s,o+tx*s,o+ty*s,fill='#1268c4',width=max(3,int(s*.08)),arrow='last',arrowshape=(14,18,7))
        if self.recommend_arrow.get() and self.recommend_move:
            try:
                m=Move.parse(self.recommend_move);fx,fy,tx,ty=m.fx,m.fy,m.tx,m.ty
                if self.flipped:fx,fy,tx,ty=8-fx,9-fy,8-tx,9-ty
                self.cv.create_line(o+fx*s,o+fy*s,o+tx*s,o+ty*s,fill='#169b45',width=max(3,int(s*.075)),arrow='last',arrowshape=(14,18,7),dash=(7,3))
            except Exception:pass
    def click(self,e):
        if self.result_saved:self.status.set('本局已经结束，请先点“新局”或“悔棋”');return
        if self.busy:return
        o,s=self.metric();x=round((e.x-o)/s);y=round((e.y-o)/s)
        if self.flipped:x,y=8-x,9-y
        if not(0<=x<9 and 0<=y<10):return
        if self.setup:
            labels={'红帅':'K','红仕':'A','红相':'E','红马':'H','红车':'R','红炮':'C','红兵':'P','黑将':'k','黑士':'a','黑象':'e','黑马':'h','黑车':'r','黑炮':'c','黑卒':'p'}
            self.board.squares[y][x]=labels[self.setup_piece.get()];self.board.history=[];self.board.red=self.side_var.get()=='红方走';self.board.positions={self.board.position_key():1};self.draw();return
        p=self.board.piece(x,y)
        if self.sel:
            m=Move(*self.sel,x,y)
            if self.board.push(m):self.sel=None;self.after_move(m)
            elif p!='.' and self.board.is_red(p)==self.board.red:self.sel=(x,y)
            else:self.status.set('不符合中国象棋规则')
        elif p!='.' and self.board.is_red(p)==self.board.red:self.sel=(x,y)
        self.draw()
    def remove_piece(self,e):
        if not self.setup:return
        o,s=self.metric();x=round((e.x-o)/s);y=round((e.y-o)/s)
        if self.flipped:x,y=8-x,9-y
        if 0<=x<9 and 0<=y<10:self.board.squares[y][x]='.';self.board.history=[];self.board.positions={self.board.position_key():1};self.draw()
    def toggle_setup(self):
        self.stop_search();self.setup=self.setup_var.get();self.setup_var.set(self.setup);self.sel=None;self.status.set('摆棋模式：左键放置，右键删除' if self.setup else '摆棋模式已关闭');self.draw()
    def check_position(self):
        self.board.red=self.side_var.get()=='红方走';ok,msg=self.board.validate_position();self.status.set(msg)
        (messagebox.showinfo if ok else messagebox.showerror)('局面检查',msg)
    def after_move(self,m):
        increment=max(0,int(self.cfg.get('increment_seconds',0))*1000)
        if int(self.cfg.get('game_minutes',0))>0:
            if not self.board.red:self.red_left+=increment
            else:self.black_left+=increment
        self.replay_moves=[x.uci() for x,_ in self.board.history];self.replay_cursor=len(self.replay_moves);self.comments={k:v for k,v in self.comments.items() if k<=self.replay_cursor};self.eval_history={k:v for k,v in self.eval_history.items() if k<=self.replay_cursor}
        if not self.clock_running:self.clock_running=True;self.last_clock=time.monotonic()
        checked=self.board.in_check();self.play_sound(checked);self.write('走棋 '+m.uci()+('　将军' if checked else ''));self.refresh_moves();self.save_session();self.status.set(('红方' if self.board.red else '黑方')+('被将军' if checked else '走棋'))
        result=self.game_result()
        if result:
            self.finish_match(result);return
        self.query_cloud(auto_continue=self.auto.get())
    def game_result(self):
        if self.board.repetition():return '三次重复局面，和棋'
        limit=max(0,int(self.cfg.get('natural_draw_plies',120)))
        if limit and self.board.noncapture_plies()>=limit:return f'连续{limit}个半回合未吃子，和棋'
        if not self.board.has_legal_move():return ('黑方胜' if self.board.red else '红方胜')+('（将死）' if self.board.in_check() else '（困毙）')
        return ''
    def tick_clock(self):
        now=time.monotonic();delta=(now-self.last_clock)*1000;self.last_clock=now
        if self.clock_running and not self.setup:
            if self.board.red:self.red_ms+=delta;self.red_left=max(0,self.red_left-delta)
            else:self.black_ms+=delta;self.black_left=max(0,self.black_left-delta)
        def fmt(ms):
            sec=ms/1000;return f'{int(sec//60):02d}:{sec%60:04.1f}'
        timed=int(self.cfg.get('game_minutes',0))>0
        if hasattr(self,'clock_text'):self.clock_text.set((f'红余 {fmt(self.red_left)}　黑余 {fmt(self.black_left)}' if timed else f'红 {fmt(self.red_ms)}　黑 {fmt(self.black_ms)}'))
        if timed and self.clock_running and not self.timeout_declared and ((self.board.red and self.red_left<=0) or (not self.board.red and self.black_left<=0)):
            self.timeout_declared=True;loser_red=self.board.red;result=('黑方胜' if loser_red else '红方胜')+'（超时）';self.finish_match(result)
        self.after(100,self.tick_clock)
    def save_result(self,result):
        if self.result_saved:return
        self.result_saved=True;path=os.path.join(DATA_DIR,'match_results.jsonl');record={'time':time.strftime('%Y-%m-%d %H:%M:%S'),'result':result,'plies':len(self.board.history),'red_ms':round(self.red_ms),'black_ms':round(self.black_ms),'moves':[m.uci() for m,_ in self.board.history]}
        with open(path,'a',encoding='utf-8') as f:f.write(json.dumps(record,ensure_ascii=False)+'\n')
    def finish_match(self,result):
        self.current_result=result;self.query_id+=1;self.search_id+=1;self.engine.send('stop');self.engine2.send('stop');self.thinking_engine=None;self.busy=False;self.clock_running=False;self.auto.set(False);self.cfg['auto']=False;self.save_cfg();self.write('比赛结束：'+result);self.status.set('比赛结束：'+result);self.save_result(result);self.save_session()
    def resign(self,red):
        side='红方' if red else '黑方'
        if self.result_saved:self.status.set('本局已经结束');return
        if messagebox.askyesno('确认认输',f'确定由{side}认输吗？'):self.finish_match(('黑方胜' if red else '红方胜')+f'（{side}认输）')
    def agree_draw(self):
        if self.result_saved:self.status.set('本局已经结束');return
        if messagebox.askyesno('协议和棋','确定双方同意和棋吗？'):self.finish_match('协议和棋')
    def pause_match(self):
        if self.result_saved:self.status.set('本局已经结束');return
        self.clock_running=not self.clock_running;self.last_clock=time.monotonic();self.status.set('比赛已继续计时' if self.clock_running else '比赛已暂停计时')
    def session_data(self):
        moves=list(self.replay_moves) if self.replay_moves else [m.uci() for m,_ in self.board.history]
        cursor=self.replay_cursor if self.replay_moves else len(moves)
        return {'version':5,'base_fen':self.base_fen,'fen':self.board.fen(),'moves':moves,'replay_cursor':max(0,min(len(moves),cursor)),'comments':self.comments,'evaluations':self.eval_history,'result':self.current_result,'red_ms':round(self.red_ms),'black_ms':round(self.black_ms),'red_left':round(self.red_left),'black_left':round(self.black_left),'flipped':self.flipped,'saved_at':time.strftime('%Y-%m-%d %H:%M:%S')}
    def save_session(self):
        path=os.path.join(DATA_DIR,'autosave_session.json');tmp=path+'.tmp';data=self.session_data()
        try:
            with open(tmp,'w',encoding='utf-8') as f:json.dump(data,f,ensure_ascii=False,indent=2);f.flush();os.fsync(f.fileno())
            for index in range(3,1,-1):
                older=f'{path}.bak{index-1}';newer=f'{path}.bak{index}'
                if os.path.isfile(older):os.replace(older,newer)
            if os.path.isfile(path):os.replace(path,path+'.bak1')
            os.replace(tmp,path)
        except Exception as ex:self.write('自动保存失败：'+str(ex)) if hasattr(self,'log') else None
    def restore_session(self):
        path=os.path.join(DATA_DIR,'autosave_session.json')
        candidates=[path]+[f'{path}.bak{i}' for i in range(1,4)];existing=[p for p in candidates if os.path.isfile(p)]
        if not existing:self.status.set('没有找到可恢复的现场');return
        errors=[]
        for candidate in existing:
            try:
                with open(candidate,'r',encoding='utf-8') as f:data=json.load(f)
                if not isinstance(data,dict):raise ValueError('现场文件结构错误')
                b=Board();base=data.get('base_fen',b.fen());b.load_fen(base);moves=list(data.get('moves',[]));cursor=max(0,min(len(moves),int(data.get('replay_cursor',len(moves)))))
                for s in moves[:cursor]:
                    if not b.push(Move.parse(s)):raise ValueError('现场包含非法着法：'+str(s))
                if not moves and data.get('fen'):b.load_fen(data['fen']);base=b.fen()
                self.stop_search();self.board=b;self.base_fen=base;self.replay_moves=moves;self.replay_cursor=cursor if moves else len(b.history);self.comments={int(k):str(v) for k,v in data.get('comments',{}).items() if int(k)<=len(moves)};self.eval_history={int(k):v for k,v in data.get('evaluations',{}).items() if int(k)<=len(moves) and isinstance(v,dict)};self.current_result=str(data.get('result','')).strip();self.red_ms=max(0,float(data.get('red_ms',0)));self.black_ms=max(0,float(data.get('black_ms',0)));default_left=max(0,int(self.cfg.get('game_minutes',0))*60000);self.red_left=max(0,float(data.get('red_left',default_left)));self.black_left=max(0,float(data.get('black_left',default_left)));self.flipped=bool(data.get('flipped',False));self.timeout_declared='超时' in self.current_result;self.result_saved=bool(self.current_result);self.sel=None;self.refresh_moves();self.draw();source='' if candidate==path else f'（自动使用备份{candidate[-1]}）';self.status.set((('已恢复终局：'+self.current_result) if self.current_result else ('已恢复 '+str(data.get('saved_at','上次'))+' 的现场'))+source);return
            except Exception as ex:errors.append(os.path.basename(candidate)+'：'+str(ex))
        messagebox.showerror('恢复现场失败','最新现场和3份备份均无法恢复。\n'+'\n'.join(errors))
    def read_results(self):
        path=os.path.join(DATA_DIR,'match_results.jsonl');rows=[]
        if not os.path.isfile(path):return rows
        with open(path,'r',encoding='utf-8') as f:
            for line in f:
                try:
                    row=json.loads(line)
                    if isinstance(row,dict):rows.append(row)
                except Exception:pass
        return rows
    def show_stats(self):
        rows=self.read_results();win=tk.Toplevel(self);win.title('双引擎比赛统计');win.geometry('760x430')
        red=sum('红方胜' in str(r.get('result','')) for r in rows);black=sum('黑方胜' in str(r.get('result','')) for r in rows);draw=len(rows)-red-black
        avg=lambda key:round(sum(float(r.get(key,0)) for r in rows)/len(rows),1) if rows else 0
        ttk.Label(win,text=f'总盘数 {len(rows)}　红胜 {red}　黑胜 {black}　和棋 {draw}　平均 {avg("plies")} 步　红均时 {avg("red_ms")/1000:.1f}s　黑均时 {avg("black_ms")/1000:.1f}s').pack(fill='x',pad=8,pady=8)
        cols=('time','result','plies','red','black');tree=ttk.Treeview(win,columns=cols,show='headings')
        for c,t,w in [('time','时间',150),('result','结果',180),('plies','步数',65),('red','红方秒',80),('black','黑方秒',80)]:tree.heading(c,text=t);tree.column(c,width=w,anchor='center')
        for r in rows:tree.insert('', 'end',values=(r.get('time',''),r.get('result',''),r.get('plies',0),round(r.get('red_ms',0)/1000,1),round(r.get('black_ms',0)/1000,1)))
        tree.pack(fill='both',expand=True,padx=8)
        ttk.Button(win,text='导出CSV',command=lambda:self.export_stats(rows)).pack(pady=8)
    def export_stats(self,rows):
        p=filedialog.asksaveasfilename(defaultextension='.csv',filetypes=[('CSV','*.csv')],initialfile='XiangqiStudio比赛统计.csv')
        if not p:return
        with open(p,'w',newline='',encoding='utf-8-sig') as f:
            w=csv.writer(f);w.writerow(['时间','结果','步数','红方毫秒','黑方毫秒','完整着法'])
            for r in rows:w.writerow([r.get('time',''),r.get('result',''),r.get('plies',0),r.get('red_ms',0),r.get('black_ms',0),' '.join(r.get('moves',[]))])
        self.status.set('比赛统计CSV已导出')
    def new(self):self.stop_search();self.board.reset();self.base_fen=self.board.fen();self.replay_moves=[];self.replay_cursor=0;self.comments={};self.eval_history={};self.current_eval={};self.current_result='';self.sel=None;self.game_start=time.time();self.red_ms=0;self.black_ms=0;self.red_left=self.black_left=max(0,int(self.cfg.get('game_minutes',0))*60000);self.timeout_declared=False;self.result_saved=False;self.refresh_moves();self.draw();self.save_session();self.status.set('新局：红方走棋')
    def undo(self):
        if self.board.pop():self.replay_moves=[x.uci() for x,_ in self.board.history];self.replay_cursor=len(self.replay_moves);self.comments={k:v for k,v in self.comments.items() if k<=self.replay_cursor};self.eval_history={k:v for k,v in self.eval_history.items() if k<=self.replay_cursor};self.current_result='';self.query_id+=1;self.result_saved=False;self.timeout_declared=False;self.refresh_moves();self.draw();self.save_session();self.status.set('已悔棋，可以继续本局')
    def jump_to(self,index):
        self.stop_search();index=max(0,min(len(self.replay_moves),index));b=Board();b.load_fen(self.base_fen)
        try:
            for s in self.replay_moves[:index]:
                if not b.push(Move.parse(s)):raise ValueError('回放遇到非法着法 '+s)
            self.board=b;self.replay_cursor=index;self.sel=None;self.refresh_moves();self.draw();self.save_session();self.status.set(f'棋谱回放：第 {index}/{len(self.replay_moves)} 步')
        except Exception as ex:messagebox.showerror('回放失败',str(ex))
    def flip(self):self.flipped=not self.flipped;self.draw()
    def copy_fen(self):self.clipboard_clear();self.clipboard_append(self.board.fen());self.status.set('FEN 已复制')
    def paste_fen(self):
        initial=''
        try:initial=self.clipboard_get()
        except Exception:pass
        value=simpledialog.askstring('载入FEN','粘贴中国象棋FEN：',initialvalue=initial,parent=self)
        if value is None:return
        try:self.stop_search();self.board.load_fen(value);self.base_fen=self.board.fen();self.replay_moves=[];self.replay_cursor=0;self.eval_history={};self.current_eval={};self.current_result='';self.result_saved=False;self.sel=None;self.refresh_moves();self.draw();self.status.set('FEN局面已载入')
        except Exception as ex:messagebox.showerror('FEN错误',str(ex))
    def clear_position(self):
        self.stop_search();self.board.clear();self.base_fen=self.board.fen();self.replay_moves=[];self.replay_cursor=0;self.eval_history={};self.current_eval={};self.current_result='';self.result_saved=False;self.sel=None;self.refresh_moves();self.draw();self.status.set('已建立仅保留将帅的最简合法局面')
    def save_game(self):
        p=filedialog.asksaveasfilename(defaultextension='.xqjson',filetypes=[('XiangqiStudio棋谱','*.xqjson'),('JSON','*.json')])
        if not p:return
        data={'format':'XiangqiStudio','version':6,'fen':self.base_fen,'moves':[m.uci() for m,_ in self.board.history],'comments':self.comments,'evaluations':self.eval_history,'result':self.current_result}
        with open(p,'w',encoding='utf-8') as f:json.dump(data,f,ensure_ascii=False,indent=2)
        self.status.set('棋谱已保存')
    def load_game(self):
        p=filedialog.askopenfilename(filetypes=[('XiangqiStudio棋谱','*.xqjson'),('JSON','*.json')])
        if not p:return
        try:
            with open(p,'r',encoding='utf-8') as f:data=json.load(f)
            b=Board();base=data.get('fen',b.fen());b.load_fen(base)
            for s in data.get('moves',[]):
                if not b.push(Move.parse(s)):raise ValueError('棋谱包含非法着法：'+s)
            self.stop_search();self.board=b;self.base_fen=base;self.replay_moves=[m.uci() for m,_ in b.history];self.replay_cursor=len(self.replay_moves);self.comments={int(k):str(v) for k,v in data.get('comments',{}).items()};self.eval_history={int(k):v for k,v in data.get('evaluations',{}).items() if isinstance(v,dict)};self.current_result=str(data.get('result','')).strip();self.result_saved=bool(self.current_result);self.sel=None;self.refresh_moves();self.draw();self.status.set(('已读取终局：'+self.current_result) if self.current_result else f'已读取 {len(b.history)} 步棋（含{len(self.eval_history)}步分析）')
        except Exception as ex:messagebox.showerror('读取失败',str(ex))
    def export_xqpgn(self):
        p=filedialog.asksaveasfilename(defaultextension='.xqpgn',filetypes=[('Xiangqi PGN文本','*.xqpgn'),('文本','*.txt')])
        if not p:return
        moves=[m.uci() for m,_ in self.board.history];result=self.current_result or self.game_result() or '*'
        lines=['[Game "Chinese Chess"]','[App "XiangqiStudio V7.4"]',f'[Date "{time.strftime("%Y.%m.%d")}"]',f'[Result "{result}"]',f'[FEN "{self.base_fen}"]','']
        for i in range(0,len(moves),2):
            rn=self.comments.get(i+1,'').replace('{','(').replace('}',')');bn=self.comments.get(i+2,'').replace('{','(').replace('}',')')
            red=moves[i]+(f' {{{rn}}}' if rn else '');black=(f' {moves[i+1]}'+(f' {{{bn}}}' if bn else '')) if i+1<len(moves) else ''
            lines.append(f'{i//2+1}. {red}{black}')
        with open(p,'w',encoding='utf-8-sig') as f:f.write('\n'.join(lines)+'\n')
        self.status.set('XQPGN文本棋谱已导出')
    def import_xqpgn(self):
        p=filedialog.askopenfilename(filetypes=[('Xiangqi PGN文本','*.xqpgn *.txt'),('全部文件','*.*')])
        if not p:return
        try:
            with open(p,'r',encoding='utf-8-sig') as f:text=f.read()
            body='\n'.join(line for line in text.splitlines() if not line.lstrip().startswith('['));parts=re.findall(r'([a-i][0-9][a-i][0-9])|\{([^}]*)\}',body,re.IGNORECASE);tokens=[];comments={}
            for move,note in parts:
                if move:tokens.append(move.lower())
                elif note.strip() and tokens:comments[len(tokens)]=note.strip()
            if not tokens:raise ValueError('没有找到UCI着法')
            b=Board();match=re.search(r'^\s*\[FEN\s+"([^"]+)"\]',text,re.MULTILINE|re.IGNORECASE);base=match.group(1) if match else b.fen();b.load_fen(base)
            for s in tokens:
                if not b.push(Move.parse(s)):raise ValueError('棋谱包含非法着法：'+s)
            result_match=re.search(r'^\s*\[Result\s+"([^"]+)"\]',text,re.MULTILINE|re.IGNORECASE);result=result_match.group(1).strip() if result_match and result_match.group(1).strip()!='*' else ''
            self.stop_search();self.board=b;self.base_fen=base;self.replay_moves=tokens;self.replay_cursor=len(tokens);self.comments=comments;self.eval_history={};self.current_eval={};self.current_result=result;self.result_saved=bool(result);self.sel=None;self.refresh_moves();self.draw();self.status.set(('已导入终局：'+result) if result else f'已导入XQPGN，共 {len(tokens)} 步，{len(comments)} 条批注')
        except Exception as ex:messagebox.showerror('导入XQPGN失败',str(ex))
    def import_book_csv(self):
        p=filedialog.askopenfilename(filetypes=[('棋库CSV','*.csv'),('全部文件','*.*')])
        if not p:return
        self.status.set('正在批量导入棋库…')
        def work():
            try:
                done,skipped=self.book.import_csv(p,lambda n,s:self.after(0,lambda:self.status.set(f'已读取 {n} 条，跳过 {s} 条…')))
                self.after(0,lambda:messagebox.showinfo('导入完成',f'处理 {done} 条，跳过 {skipped} 条。\n去重后本地库共 {self.book.count()} 条。'))
                self.after(0,lambda:self.status.set(f'棋库导入完成，共 {self.book.count()} 条'))
            except Exception as ex:self.after(0,lambda ex=ex:messagebox.showerror('导入失败',str(ex)))
        threading.Thread(target=work,daemon=True).start()
    def export_book_csv(self):
        p=filedialog.asksaveasfilename(defaultextension='.csv',filetypes=[('棋库CSV','*.csv')],initialfile='XiangqiStudio本地棋库.csv')
        if not p:return
        self.status.set('正在导出棋库…')
        def work():
            try:
                done=self.book.export_csv(p,lambda n:self.after(0,lambda:self.status.set(f'已导出 {n} 条…')))
                self.after(0,lambda:messagebox.showinfo('导出完成',f'已导出 {done} 条着法。'))
                self.after(0,lambda:self.status.set(f'棋库导出完成，共 {done} 条'))
            except Exception as ex:self.after(0,lambda ex=ex:messagebox.showerror('导出失败',str(ex)))
        threading.Thread(target=work,daemon=True).start()
    def backup_book(self):
        default='local_book_'+time.strftime('%Y%m%d_%H%M%S')+'.db';p=filedialog.asksaveasfilename(initialfile=default,defaultextension='.db',filetypes=[('SQLite棋库备份','*.db')])
        if p:self.book.backup(p);self.status.set(f'本地棋库已备份，共 {self.book.count()} 条')
    def restore_book(self):
        p=filedialog.askopenfilename(filetypes=[('SQLite棋库备份','*.db')])
        if not p:return
        try:
            auto=os.path.join(DATA_DIR,'book','before_restore_'+time.strftime('%Y%m%d_%H%M%S')+'.db');self.book.backup(auto);self.book.restore(p);self.status.set(f'恢复完成，共 {self.book.count()} 条；旧库已自动备份')
        except Exception as ex:messagebox.showerror('恢复失败',str(ex))
    def pick_engine(self):
        p=filedialog.askopenfilename(filetypes=[('Engine','*.exe'),('All','*.*')]);
        if p:self.cfg['engine']=p;self.save_cfg();self.status.set('已选择引擎')
    def pick_engine2(self):
        p=filedialog.askopenfilename(filetypes=[('Engine','*.exe'),('All','*.*')]);
        if p:self.cfg['engine2']=p;self.save_cfg();self.status.set('已选择黑方引擎')
    def pick_nnue(self):
        p=filedialog.askopenfilename(filetypes=[('NNUE','*.nnue'),('All','*.*')]);
        if p:self.cfg['nnue']=p;self.save_cfg();self.status.set('已选择 NNUE')
    def apply_engine_preset(self,name):
        values=ENGINE_PRESETS.get(name)
        if not values:return
        if self.busy:self.stop_search()
        self.engine.stop();self.engine2.stop();self.thinking_engine=None
        self.cfg.update(values);self.cfg['engine_preset']=name;self.movetime.set(values['movetime']);self.save_cfg()
        self.status.set(f'已应用{name}档：{values["threads"]}线程 / Hash {values["hash"]}MB / MultiPV {values["multipv"]} / {values["movetime"]}ms；下次计算自动生效')
    def start_engine(self):
        if self.busy:self.status.set('当前已有任务正在运行');return
        self.search_id+=1;sid=self.search_id;self.busy=True;self.status.set('正在后台启动红方引擎…')
        args=(self.resolve_path(self.cfg.get('nnue','')),int(self.cfg.get('threads',6)),int(self.cfg.get('hash',1024)),int(self.cfg.get('multipv',3)));first=self.resolve_path(self.cfg.get('engine',''));second=self.resolve_path(self.cfg.get('engine2','') or self.cfg.get('engine',''))
        def work():
            try:
                self.engine.start(first,*args)
                if sid!=self.search_id:self.engine.stop();return
                self.after(0,lambda:self.status.set('红方引擎就绪，正在后台启动黑方引擎…'))
                self.engine2.start(second,*args)
                if sid!=self.search_id:self.engine.stop();self.engine2.stop();return
                message=f'红方 {self.engine.protocol.upper()} / 黑方 {self.engine2.protocol.upper()} 双引擎就绪';error=''
            except Exception as ex:message='';error=str(ex);self.engine.stop();self.engine2.stop()
            self.after(0,lambda:self.finish_start_engine(message,error,sid))
        threading.Thread(target=work,daemon=True).start()
    def finish_start_engine(self,message,error,sid):
        if sid!=self.search_id:return
        self.busy=False
        if error:self.status.set('引擎启动失败');messagebox.showerror('引擎启动失败',error)
        else:self.status.set(message);self.write(message)
    def self_test(self):
        self.status.set('系统自检中…')
        def work():
            red=self.resolve_path(self.cfg.get('engine',''));black=self.resolve_path(self.cfg.get('engine2','') or self.cfg.get('engine',''));nnue=self.resolve_path(self.cfg.get('nnue',''))
            rows=[('配置文件',os.path.isfile(CONFIG),CONFIG),('红方引擎',os.path.isfile(red),red),('黑方引擎',os.path.isfile(black),black),('NNUE',os.path.isfile(nnue),nnue),('本地棋库',True,f'{self.book.count()} 条')]
            cloud=self.cloud.query(Board().fen());rows.append(('ChessDB云库',bool(cloud),f'返回 {len(cloud)} 条' if cloud else '未返回着法/网络不可用'))
            path=os.path.join(DATA_DIR,'self_test_report.txt')
            with open(path,'w',encoding='utf-8') as f:
                f.write('XiangqiStudio V7.4 系统自检\n'+time.strftime('%Y-%m-%d %H:%M:%S')+'\n\n')
                for name,ok,detail in rows:f.write(('通过' if ok else '失败')+f'  {name}: {detail}\n')
            text='\n'.join(('✓ ' if ok else '✗ ')+name+'：'+str(detail) for name,ok,detail in rows)
            self.after(0,lambda:messagebox.showinfo('系统自检结果',text));self.after(0,lambda:self.status.set('系统自检完成，报告已保存'))
        threading.Thread(target=work,daemon=True).start()
    def engine_settings(self):
        win=tk.Toplevel(self);win.title('引擎设置');win.transient(self);win.grab_set();values={}
        fields=[('线程数','threads',1,64,6),('Hash MB','hash',16,32768,1024),('多主变','multipv',1,10,3),('每步毫秒','movetime',100,600000,1000),('比赛分钟(0不限)','game_minutes',0,1440,0),('每步加秒','increment_seconds',0,600,0),('未吃子限着(半回合)','natural_draw_plies',0,9999,120),('随机分差','book_random_margin',0,9999,30),('云库最低分','cloud_min_score',-999999,999999,-999999),('云库超时ms','cloud_timeout_ms',200,10000,1200)]
        for row,(label,key,lo,hi,default) in enumerate(fields):
            ttk.Label(win,text=label).grid(row=row,column=0,padx=10,pady=7,sticky='e');v=tk.IntVar(value=int(self.cfg.get(key,default)));values[key]=v;ttk.Spinbox(win,from_=lo,to=hi,textvariable=v,width=10).grid(row=row,column=1,padx=10,pady=7)
        mode=tk.StringVar(value=self.cfg.get('book_mode','最高分'));ttk.Label(win,text='开局库策略').grid(row=len(fields),column=0,padx=10,pady=7,sticky='e');ttk.Combobox(win,textvariable=mode,state='readonly',values=('最高分','高分随机'),width=10).grid(row=len(fields),column=1,padx=10,pady=7)
        def save():
            try:
                for _,key,lo,hi,_ in fields:self.cfg[key]=min(hi,max(lo,int(values[key].get())))
                self.cfg['book_mode']=mode.get();self.movetime.set(self.cfg['movetime']);self.cloud.timeout=self.cfg['cloud_timeout_ms']/1000;self.red_left=self.black_left=max(0,self.cfg['game_minutes']*60000);self.timeout_declared=False;self.save_cfg();win.destroy();self.status.set('引擎、棋库策略、比赛用时及云库设置已保存')
            except Exception as ex:messagebox.showerror('设置错误',str(ex),parent=win)
        ttk.Button(win,text='保存',command=save).grid(row=len(fields)+1,column=0,columnspan=2,pady=10)
    def query_cloud(self,auto_continue=False):
        self.query_id+=1;qid=self.query_id;fen=self.board.fen();self.status.set('查询本地库和云库（超时自动跳过）')
        def work():
            local=[(m,str(score) if score is not None else '',source) for m,score,source in self.book.entries(fen)]
            if auto_continue and local:self.after(0,lambda:self.show_moves(local,qid,fen,True));return
            cached=self.cloud_cache.get(fen);remote=self.cloud.query(fen) if self.cfg.get('cloud',True) else []
            if remote:self.cloud_cache.put(fen,remote)
            elif not cached:cached=self.cloud_cache.get(fen,allow_stale=True)
            cloud_rows=remote or cached
            self.after(0,lambda:self.show_moves(local+cloud_rows,qid,fen,auto_continue))
        threading.Thread(target=work,daemon=True).start()
    def show_moves(self,items,qid=None,fen=None,auto_continue=False):
        if qid is not None and (qid!=self.query_id or fen!=self.board.fen()):return
        self.tree.delete(*self.tree.get_children());unique=[];seen=set()
        minimum=int(self.cfg.get('cloud_min_score',-999999))
        for row in items:
            try:score=int(str(row[1]).replace('+','')) if row[1] not in ('','本地') else 999999
            except Exception:score=999999
            if score<minimum:continue
            if row[0] not in seen:unique.append(row);seen.add(row[0])
        items=unique
        for row in items:
            try:cn=self.board.chinese(Move.parse(row[0]))
            except Exception:cn=''
            self.tree.insert('', 'end',values=(row[0],cn,row[1],row[2]))
        self.status.set(('红方' if self.board.red else '黑方')+f'走棋；本地库共 {self.book.count()} 条')
        if auto_continue:
            valid=[]
            for row in items:
                try:
                    m=Move.parse(row[0])
                    if self.board.legal(m):
                        try:score=int(str(row[1]).replace('+',''))
                        except Exception:score=0
                        valid.append((m,score,str(row[2] or 'book')))
                except Exception:pass
            if valid:
                m,score,source=self.choose_book_entry(valid)
                if self.learn.get():self.book.add(fen,m.uci(),'learn:'+source,score)
                if self.board.push(m):self.draw();self.after_move(m)
            else:self.after(30,self.go)
    def choose_book_entry(self,candidates):
        if self.cfg.get('book_mode','最高分')!='高分随机':return max(candidates,key=lambda x:x[1])
        best=max(item[1] for item in candidates);margin=max(0,int(self.cfg.get('book_random_margin',30)));pool=[item for item in candidates if item[1]>=best-margin]
        return random.choice(pool)
    def play_cloud(self,e=None):
        if self.result_saved:self.status.set('本局已经结束，请先点“新局”或“悔棋”');return
        sel=self.tree.selection()
        if not sel:return
        try:m=Move.parse(self.tree.item(sel[0],'values')[0])
        except Exception:return
        if self.board.push(m):self.draw();self.after_move(m)
    def book_menu(self,e):
        row=self.tree.identify_row(e.y)
        if row:self.tree.selection_set(row);self.popup.tk_popup(e.x_root,e.y_root)
    def selected_book_move(self):
        sel=self.tree.selection()
        return self.tree.item(sel[0],'values')[0] if sel else ''
    def save_selected_book(self):
        move=self.selected_book_move()
        if move:self.book.add(self.board.fen(),move);self.status.set(f'已保存 {move}；本地库共 {self.book.count()} 条');self.query_cloud()
    def remove_selected_book(self):
        move=self.selected_book_move()
        if move:self.book.remove(self.board.fen(),move);self.status.set(f'已删除 {move}；本地库共 {self.book.count()} 条');self.query_cloud()
    def edit_book_score(self):
        move=self.selected_book_move()
        if not move:return
        score=simpledialog.askinteger('修改着法分数',f'{move} 的分数：',minvalue=-999999,maxvalue=999999,parent=self)
        if score is not None:self.book.set_score(self.board.fen(),move,score);self.query_cloud();self.status.set(f'{move} 分数已改为 {score}')
    def show_book_stats(self):
        sources=self.book.source_counts();text=f'局面数：{self.book.position_count()}\n着法数：{self.book.count()}\n云库缓存局面：{self.cloud_cache.count()}\n\n来源统计：\n'+('\n'.join(f'{name or "未标记"}：{count}' for name,count in sources) if sources else '本地库为空')
        messagebox.showinfo('本地棋库统计',text)
    def clear_cloud_cache(self):
        if messagebox.askyesno('清理云库缓存','确定清除全部云库缓存吗？本地开局库不会受影响。'):self.cloud_cache.clear();self.status.set('云库缓存已清理')
    def maintain_book(self):
        check=self.book.integrity_check()
        if check.lower()!='ok':messagebox.showerror('棋库维护','数据库完整性检查失败：'+check);return
        threshold=simpledialog.askinteger('棋库维护','删除分数低于多少的着法？\n取消则只检查，不删除。',initialvalue=-300,minvalue=-999999,maxvalue=999999,parent=self)
        if threshold is None:self.status.set('棋库完整性检查通过');return
        count=self.book.below_score_count(threshold)
        if count==0:self.status.set('完整性通过，没有符合清理条件的着法');return
        if not messagebox.askyesno('确认清理',f'将删除分数低于 {threshold} 的 {count} 条着法。\n清理前会自动备份，确定继续吗？'):return
        backup=os.path.join(DATA_DIR,'book','before_cleanup_'+time.strftime('%Y%m%d_%H%M%S')+'.db');self.book.backup(backup);deleted=self.book.delete_below_score(threshold);self.status.set(f'已删除 {deleted} 条，正在压缩棋库…')
        def work():
            try:self.book.vacuum();self.after(0,lambda:messagebox.showinfo('维护完成',f'已删除 {deleted} 条低分着法并压缩数据库。\n备份：{backup}'))
            except Exception as ex:self.after(0,lambda ex=ex:messagebox.showerror('压缩失败',str(ex)))
        threading.Thread(target=work,daemon=True).start()
    def go(self):
        if self.result_saved:self.status.set('本局已经结束，请先点“新局”或“悔棋”');return
        if self.busy or self.setup:
            if self.setup:self.status.set('请先关闭摆棋模式并检查局面')
            return
        if not self.clock_running:self.clock_running=True;self.last_clock=time.monotonic()
        self.search_id+=1;sid=self.search_id;self.busy=True;self.pv_lines={};self.recommend_move='';self.eval_cp=0;self.current_eval={};self.set_analysis('等待引擎分析…');self.draw();fen=self.board.fen();self.search_fen=fen;active=self.engine if self.board.red else self.engine2;backup=self.engine2 if active is self.engine else self.engine;self.status.set(('红方' if self.board.red else '黑方')+'引擎思考中…')
        def work():
            move='';errors=[]
            for attempt,engine in enumerate((active,backup),1):
                if sid!=self.search_id:self.thinking_engine=None;return
                try:
                    self.thinking_engine=engine
                    if attempt==2:self.after(0,lambda:self.write('主用引擎失败，已自动切换备用本地引擎'))
                    if not engine.alive():
                        path=self.cfg.get('engine','') if engine is self.engine else (self.cfg.get('engine2','') or self.cfg.get('engine',''))
                        engine.start(self.resolve_path(path),self.resolve_path(self.cfg.get('nnue','')),int(self.cfg.get('threads',6)),int(self.cfg.get('hash',1024)),int(self.cfg.get('multipv',3)))
                        self.after(0,lambda:self.write('本地引擎进程已自动启动/重启'))
                    timed=int(self.cfg.get('game_minutes',0))>0;inc=int(self.cfg.get('increment_seconds',0))*1000
                    move=engine.bestmove(fen,int(self.movetime.get()),self.on_info,self.red_left if timed else None,self.black_left if timed else None,inc,inc)
                    probe=Board();probe.load_fen(fen)
                    if move and probe.legal(Move.parse(move)):break
                    errors.append('未返回合法着法');move=''
                except Exception as ex:errors.append(str(ex));move=''
            self.thinking_engine=None;err='；'.join(errors)
            self.after(0,lambda:self.finish_engine(move,err,sid,fen))
        threading.Thread(target=work,daemon=True).start()
    def force_or_go(self):
        if self.busy:
            active=self.thinking_engine or (self.engine if self.board.red else self.engine2);active.send('stop');self.status.set('已要求当前引擎立即走棋…')
        else:self.go()
    def play_recommend(self):
        if self.result_saved:self.status.set('本局已经结束，请先点“新局”或“悔棋”');return
        if not self.recommend_move:self.status.set('当前没有可用的引擎推荐着法');return
        try:m=Move.parse(self.recommend_move)
        except Exception:self.status.set('推荐着法格式错误');return
        if not self.board.legal(m):self.status.set('推荐着法与当前局面不一致，已忽略');return
        self.search_id+=1;self.engine.send('stop');self.engine2.send('stop');self.busy=False
        fen=self.board.fen();score=int(self.eval_cp if self.board.red else -self.eval_cp)
        if self.board.push(m):
            if self.learn.get():self.book.add(fen,m.uci(),'learn:engine-recommend',score)
            if self.current_eval:self.eval_history[len(self.board.history)]=dict(self.current_eval)
            self.sel=None;self.recommend_move='';self.draw();self.after_move(m)
    def finish_engine(self,s,err,sid=None,fen=None):
        if sid is not None and (sid!=self.search_id or fen!=self.board.fen()):return
        self.busy=False
        mover_red=self.board.red
        try:m=Move.parse(s);ok=self.board.push(m)
        except Exception:ok=False
        if ok:
            if self.learn.get():self.book.add(getattr(self,'search_fen',''),m.uci(),'learn:engine',int(self.eval_cp if mover_red else -self.eval_cp))
            if self.current_eval:self.eval_history[len(self.board.history)]=dict(self.current_eval)
            self.draw();self.after_move(m)
        else:self.status.set('引擎未返回合法着法：'+(err or s))
    def on_info(self,line):
        parts=line.split(); values={}
        for key in ('depth','seldepth','nodes','nps','multipv'):
            if key in parts:
                i=parts.index(key);values[key]=parts[i+1] if i+1<len(parts) else ''
        index=int(values.get('multipv','1') or 1);score=''
        if 'score' in parts:
            i=parts.index('score');score=' '.join(parts[i+1:i+3])
            try:
                raw=int(parts[i+2]);cp=(100000 if raw>0 else -100000) if parts[i+1]=='mate' else raw
                if index==1:self.eval_cp=cp if self.board.red else -cp
            except Exception:pass
        pv=' '.join(parts[parts.index('pv')+1:]) if 'pv' in parts else ''
        win=100/(1+math.exp(-max(-2000,min(2000,self.eval_cp))/300));self.pv_lines[index]=f"PV{index} 深度{values.get('depth','-')} 分数{score or '-'} 红方胜率约{win:.1f}% NPS {values.get('nps','-')}\n{pv}"
        if index==1:
            if pv:self.recommend_move=pv.split()[0]
            try:depth=int(values.get('depth',0) or 0)
            except Exception:depth=0
            self.current_eval={'cp':int(self.eval_cp),'depth':depth,'pv':pv}
        text='\n'.join(self.pv_lines[k] for k in sorted(self.pv_lines))
        now=time.monotonic()
        if now-self.last_info_ui>=.1:self.last_info_ui=now;self.after(0,lambda:(self.set_analysis(text),self.draw()))
    def set_analysis(self,text):self.analysis.configure(state='normal');self.analysis.delete('1.0','end');self.analysis.insert('end',text);self.analysis.configure(state='disabled')
    def stop_search(self):self.query_id+=1;self.search_id+=1;self.clock_running=False;self.auto.set(False);self.cfg['auto']=False;self.save_cfg();self.engine.send('stop');self.engine2.send('stop');self.thinking_engine=None;self.busy=False;self.status.set('已停止')
    def toggle_auto(self):
        self.cfg['auto']=self.auto.get();self.save_cfg()
        if self.auto.get():self.query_cloud(auto_continue=True)
        else:self.engine.send('stop');self.engine2.send('stop')
    def save_time(self):
        try:self.cfg['movetime']=max(100,int(self.movetime.get()));self.save_cfg()
        except Exception:pass
    def save_visual(self):
        self.cfg.update({'hints':self.hints.get(),'arrows':self.arrows.get(),'recommend_arrow':self.recommend_arrow.get(),'sound':self.sound.get(),'learn':self.learn.get()});self.save_cfg();self.draw()
    def play_sound(self,checked=False):
        if not self.sound.get():return
        try:
            import winsound;winsound.MessageBeep(winsound.MB_ICONEXCLAMATION if checked else winsound.MB_OK)
        except Exception:
            try:self.bell()
            except Exception:pass
    def refresh_moves(self):
        self.moves.delete(0,'end');temp=Board();shown=[]
        for m,_ in self.board.history:
            ply=len(shown)+1;note=f' {{{self.comments[ply]}}}' if ply in self.comments else '';ev=self.eval_history.get(ply,{});rating=(f' [{int(ev.get("cp",0))/100:+.2f}@d{int(ev.get("depth",0))}]' if ev else '');shown.append(f'{temp.chinese(m)} [{m.uci()}]{rating}{note}');temp.push(m)
        for i in range(0,len(shown),2):self.moves.insert('end',f'{i//2+1:03d}. {shown[i]}　{shown[i+1] if i+1<len(shown) else ""}')
        if shown:self.moves.see('end')
    def move_comment_menu(self,e):
        if self.moves.size()==0:return
        row=self.moves.nearest(e.y);self.comment_ply=min(len(self.board.history),row*2+(2 if e.x>self.moves.winfo_width()/2 else 1));self.moves.selection_clear(0,'end');self.moves.selection_set(row);self.comment_popup.tk_popup(e.x_root,e.y_root)
    def selected_comment_ply(self):
        sel=self.moves.curselection()
        if not sel:return 0
        return getattr(self,'comment_ply',sel[0]*2+1)
    def edit_move_comment(self):
        ply=self.selected_comment_ply()
        if not ply:return
        note=simpledialog.askstring('棋谱批注',f'第 {ply} 步批注：',initialvalue=self.comments.get(ply,''),parent=self)
        if note is not None:
            if note.strip():self.comments[ply]=note.strip()
            else:self.comments.pop(ply,None)
            self.refresh_moves();self.save_session()
    def delete_move_comment(self):
        ply=self.selected_comment_ply()
        if ply:self.comments.pop(ply,None);self.refresh_moves();self.save_session()
    def write(self,s):self.log.configure(state='normal');self.log.insert('end',s+'\n');self.log.see('end');self.log.configure(state='disabled')
    def report_callback_exception(self,exc,value,tb):
        detail=''.join(traceback.format_exception(exc,value,tb));LOGGER.error('界面异常\n%s',detail)
        try:self.status.set('发生异常，软件已保护运行；详情见故障日志');messagebox.showerror('XiangqiStudio异常','操作发生错误，软件没有退出。\n请在“帮助→查看故障日志”中查看详情。')
        except Exception:pass
    def show_log(self):
        path=os.path.join(DATA_DIR,'XiangqiStudio.log');win=tk.Toplevel(self);win.title('故障日志');win.geometry('820x480');box=tk.Text(win,wrap='none',font=('Consolas',10));box.pack(fill='both',expand=True)
        try:
            with open(path,'r',encoding='utf-8',errors='replace') as f:text=f.read()[-100000:]
        except Exception as ex:text='暂时没有日志：'+str(ex)
        box.insert('1.0',text);box.configure(state='disabled');box.see('end')
    def close(self):
        LOGGER.info('正常退出');self.cfg['geometry']=self.winfo_geometry();self.cfg['ui_scale']=round(self.ui_scale,2);self.save_cfg();self.save_session();self.engine.stop();self.engine2.stop();self.book.close();self.cloud_cache.close();self.destroy()

if __name__=='__main__':
    try:LOGGER.info('启动 V7.4');App().mainloop()
    except Exception:
        LOGGER.exception('启动或主循环异常');raise
