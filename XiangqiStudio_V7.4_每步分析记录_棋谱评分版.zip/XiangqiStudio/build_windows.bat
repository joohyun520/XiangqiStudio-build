@echo off
chcp 65001 >nul
setlocal
cd /d "%~dp0"
where py >nul 2>nul || (echo 请先安装 Python 3.11 或更高版本&pause&exit /b 1)
py -m pip install --upgrade pyinstaller
if errorlevel 1 (echo PyInstaller 安装失败&pause&exit /b 1)
py -m PyInstaller --noconfirm --clean --windowed --onefile --name XiangqiStudio --distpath "release" --workpath "build" --specpath "build" app.py
if errorlevel 1 (echo 编译失败&pause&exit /b 1)
if not exist "release\engine" mkdir "release\engine"
copy /y "README_使用说明.txt" "release\README_使用说明.txt" >nul
copy /y "config.json" "release\config.json" >nul
copy /y "验证发布包.bat" "release\验证发布包.bat" >nul
if exist "engine\fairy-stockfish-largeboard_x86-64-bmi2.exe" copy /y "engine\fairy-stockfish-largeboard_x86-64-bmi2.exe" "release\engine\" >nul
if exist "engine\xiangqi-zy.nnue" copy /y "engine\xiangqi-zy.nnue" "release\engine\" >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "Compress-Archive -Path 'release\*' -DestinationPath 'XiangqiStudio_V7.4_Windows发布包.zip' -Force"
if errorlevel 1 (echo EXE已生成，但自动压缩失败&pause&exit /b 1)
echo.
echo 编译完成：%~dp0release\XiangqiStudio.exe
echo 发布包：%~dp0XiangqiStudio_V7.4_Windows发布包.zip
pause
