from __future__ import annotations
from dataclasses import dataclass
from copy import deepcopy

FILES, RANKS = 9, 10

START = [
    list("rheakaehr"), list("........."), list(".c.....c."), list("p.p.p.p.p"),
    list("........."), list("........."), list("P.P.P.P.P"), list(".C.....C."),
    list("........."), list("RHEAKAEHR")
]

NAMES = {"K":"帅","A":"仕","E":"相","H":"马","R":"车","C":"炮","P":"兵",
         "k":"将","a":"士","e":"象","h":"马","r":"车","c":"炮","p":"卒"}
CN_NUM='零一二三四五六七八九'

@dataclass(frozen=True)
class Move:
    fx: int; fy: int; tx: int; ty: int
    def uci(self): return f"{chr(97+self.fx)}{9-self.fy}{chr(97+self.tx)}{9-self.ty}"
    @staticmethod
    def parse(s: str) -> "Move":
        s=s.strip().lower()
        if len(s)<4: raise ValueError("invalid move")
        return Move(ord(s[0])-97, 9-int(s[1]), ord(s[2])-97, 9-int(s[3]))

class Board:
    def __init__(self): self.reset()
    def reset(self):
        self.squares=deepcopy(START); self.red=True; self.history=[]; self.positions={self.position_key():1}
    def position_key(self): return ''.join(''.join(r) for r in self.squares)+('r' if self.red else 'b')
    def piece(self,x,y): return self.squares[y][x] if 0<=x<9 and 0<=y<10 else None
    @staticmethod
    def is_red(p): return p is not None and p!='.' and p.isupper()
    def same_side(self,a,b): return a!='.' and b!='.' and self.is_red(a)==self.is_red(b)
    def between(self,m):
        n=0
        if m.fx==m.tx:
            for y in range(min(m.fy,m.ty)+1,max(m.fy,m.ty)): n+=self.piece(m.fx,y)!='.'
        elif m.fy==m.ty:
            for x in range(min(m.fx,m.tx)+1,max(m.fx,m.tx)): n+=self.piece(x,m.fy)!='.'
        return n
    def pseudo_legal(self,m):
        if not all((0<=m.fx<9,0<=m.tx<9,0<=m.fy<10,0<=m.ty<10)): return False
        p,t=self.piece(m.fx,m.fy),self.piece(m.tx,m.ty)
        if p=='.' or self.is_red(p)!=self.red or self.same_side(p,t): return False
        dx,dy=abs(m.tx-m.fx),abs(m.ty-m.fy); q=p.lower(); red=self.is_red(p)
        if q=='r': return (dx==0 or dy==0) and self.between(m)==0
        if q=='c': return (dx==0 or dy==0) and self.between(m)==(0 if t=='.' else 1)
        if q=='h':
            if sorted((dx,dy))!=[1,2]: return False
            lx=m.fx+(m.tx-m.fx)//2 if dx==2 else m.fx
            ly=m.fy+(m.ty-m.fy)//2 if dy==2 else m.fy
            return self.piece(lx,ly)=='.'
        if q=='e':
            home = m.ty>=5 if red else m.ty<=4
            return dx==dy==2 and home and self.piece((m.fx+m.tx)//2,(m.fy+m.ty)//2)=='.'
        if q=='a': return dx==dy==1 and 3<=m.tx<=5 and ((7<=m.ty<=9) if red else (0<=m.ty<=2))
        if q=='k':
            if m.fx==m.tx and t.lower()=='k' and self.between(m)==0: return True
            return dx+dy==1 and 3<=m.tx<=5 and ((7<=m.ty<=9) if red else (0<=m.ty<=2))
        if q=='p':
            forward=-1 if red else 1; crossed=m.fy<=4 if red else m.fy>=5
            return (m.ty-m.fy==forward and dx==0) or (crossed and dy==0 and dx==1)
        return False
    def king_pos(self,red):
        target='K' if red else 'k'
        for y,row in enumerate(self.squares):
            for x,p in enumerate(row):
                if p==target:return x,y
        return None
    def attacked(self,x,y,by_red):
        old=self.red; self.red=by_red
        try:
            for fy,row in enumerate(self.squares):
                for fx,p in enumerate(row):
                    if p!='.' and self.is_red(p)==by_red and self.pseudo_legal(Move(fx,fy,x,y)): return True
        finally:self.red=old
        return False
    def legal(self,m):
        if not self.pseudo_legal(m): return False
        moving=self.red; captured=self.piece(m.tx,m.ty); p=self.piece(m.fx,m.fy)
        self.squares[m.ty][m.tx]=p; self.squares[m.fy][m.fx]='.'
        kp=self.king_pos(moving); bad=kp is None or self.attacked(*kp,not moving)
        self.squares[m.fy][m.fx]=p; self.squares[m.ty][m.tx]=captured
        return not bad
    def push(self,m):
        if not self.legal(m): return False
        self.history.append((m,self.piece(m.tx,m.ty)))
        self.squares[m.ty][m.tx]=self.piece(m.fx,m.fy); self.squares[m.fy][m.fx]='.'; self.red=not self.red
        k=self.position_key();self.positions[k]=self.positions.get(k,0)+1
        return True
    def pop(self):
        if not self.history:return False
        k=self.position_key();self.positions[k]=max(0,self.positions.get(k,1)-1)
        m,c=self.history.pop(); self.squares[m.fy][m.fx]=self.squares[m.ty][m.tx]; self.squares[m.ty][m.tx]=c; self.red=not self.red
        return True
    def repetition(self): return self.positions.get(self.position_key(),0)>=3
    def noncapture_plies(self):
        """Return consecutive half-moves since the most recent capture."""
        count=0
        for _,captured in reversed(self.history):
            if captured!='.':break
            count+=1
        return count
    def in_check(self,red=None):
        red=self.red if red is None else red;kp=self.king_pos(red)
        return kp is None or self.attacked(*kp,not red)
    def has_legal_move(self):
        for fy,row in enumerate(self.squares):
            for fx,p in enumerate(row):
                if p!='.' and self.is_red(p)==self.red:
                    for ty in range(10):
                        for tx in range(9):
                            if self.legal(Move(fx,fy,tx,ty)):return True
        return False
    def fen(self):
        rows=[]
        for row in self.squares:
            out=''; empty=0
            for p in row:
                if p=='.': empty+=1
                else:
                    if empty:out+=str(empty);empty=0
                    out+=p
            if empty:out+=str(empty)
            rows.append(out)
        return '/'.join(rows)+(' w' if self.red else ' b')+' - - 0 1'
    def chinese(self,m):
        p=self.piece(m.fx,m.fy)
        if not p or p=='.':return m.uci()
        red=p.isupper();file_from=(9-m.fx if red else m.fx+1);file_to=(9-m.tx if red else m.tx+1)
        num=lambda n:CN_NUM[n] if red else str(n)
        same=[y for y in range(10) if self.piece(m.fx,y)==p]
        prefix=NAMES[p]+num(file_from)
        if len(same)==2:
            front=min(same) if red else max(same);prefix=('前' if m.fy==front else '后')+NAMES[p]
        if m.fy==m.ty:return prefix+'平'+num(file_to)
        forward=(m.ty<m.fy) if red else (m.ty>m.fy);direction='进' if forward else '退'
        value=file_to if p.lower() in ('h','e','a') else abs(m.ty-m.fy)
        return prefix+direction+num(value)
    def load_fen(self,fen):
        parts=fen.strip().split()
        if not parts:raise ValueError('FEN不能为空')
        rows=parts[0].split('/')
        if len(rows)!=10:raise ValueError('FEN必须包含10行')
        allowed=set('kaehrcpKAEHRCP');board=[]
        for text in rows:
            row=[]
            for ch in text:
                if ch.isdigit():row.extend('.'*int(ch))
                elif ch in allowed:row.append(ch)
                else:raise ValueError('FEN包含未知棋子：'+ch)
            if len(row)!=9:raise ValueError('FEN每行必须为9格')
            board.append(row)
        if sum(p=='K' for r in board for p in r)!=1 or sum(p=='k' for r in board for p in r)!=1:raise ValueError('局面必须各有一个帅和将')
        self.squares=board;self.red=len(parts)<2 or parts[1] in ('w','r');self.history=[];self.positions={self.position_key():1}
    def clear(self):
        self.squares=[list('.........') for _ in range(10)];self.squares[9][4]='K';self.squares[0][3]='k';self.red=True;self.history=[];self.positions={self.position_key():1}
    def validate_position(self):
        rk=self.king_pos(True);bk=self.king_pos(False)
        if rk is None or bk is None:return False,'必须各有一个帅和将'
        if not (3<=rk[0]<=5 and 7<=rk[1]<=9):return False,'红帅必须在九宫内'
        if not (3<=bk[0]<=5 and 0<=bk[1]<=2):return False,'黑将必须在九宫内'
        if rk[0]==bk[0] and all(self.piece(rk[0],y)=='.' for y in range(bk[1]+1,rk[1])):return False,'将帅不能直接照面'
        limits={'K':1,'A':2,'E':2,'H':2,'R':2,'C':2,'P':5,'k':1,'a':2,'e':2,'h':2,'r':2,'c':2,'p':5}
        for p,n in limits.items():
            if sum(x==p for row in self.squares for x in row)>n:return False,f'{NAMES[p]}数量超过规则限制'
        return True,'局面检查通过'
